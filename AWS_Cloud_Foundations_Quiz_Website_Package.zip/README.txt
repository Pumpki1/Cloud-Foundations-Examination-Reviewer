AWS CLOUD FOUNDATIONS INTERACTIVE QUIZ

OPEN THE QUIZ
1. Download AWS_Cloud_Foundations_Interactive_Quiz.html.
2. Double-click it or open it with Chrome, Edge, Firefox, or another modern browser.
3. No installation or internet connection is required after downloading.
4. Use Exam Mode to hide answers until you submit. Use Study Mode to check each answer immediately.
5. Take all 109 questions or choose one of the 13 parts. The score report includes your score by part and explanations.

MAKE A SHAREABLE WEBSITE LINK
1. Extract the website package ZIP to a folder. The folder includes index.html, which is the website homepage.
2. Open https://app.netlify.com/drop.
3. Drag the extracted folder containing index.html into the upload area.
4. Follow any prompts and check the site's visibility settings. Open the resulting site URL in a private/incognito window to make sure classmates can access it before sharing the link.

The public web URL is created by the hosting service after deployment. The HTML file itself can also be sent directly to classmates.

SOURCE NOTE
Question wording, answer keys, and explanations are based on the supplied AWS Cloud Foundations Practice Exam and Answer Key PDF. The source answer key has been preserved and has not been independently revalidated against the latest AWS documentation. This is a study tool, not an official AWS exam.
